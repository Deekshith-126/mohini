from flask import Blueprint, render_template, request, session, redirect, flash
import sqlite3
import joblib
import pandas as pd
from config import DATABASE

prediction_bp = Blueprint("prediction", __name__)


# =========================================================
# LOAD MACHINE LEARNING MODEL
# =========================================================

model = joblib.load("models/best_model.pkl")


# =========================================================
# LOAD DATASET
# =========================================================

dataset = pd.read_csv(
    "dataset/upi_fraud_detection.csv"
)


# =========================================================
# REMOVE UNWANTED COLUMNS
# =========================================================

drop_cols = [
    "transaction_id",
    "user_id",
    "merchant_id",
    "timestamp",
    "is_fraud"
]

for col in drop_cols:

    if col in dataset.columns:

        dataset.drop(
            columns=[col],
            inplace=True
        )


# =========================================================
# PREDICTION ROUTE
# =========================================================

@prediction_bp.route(
    "/prediction",
    methods=["GET", "POST"]
)
def prediction():

    # -----------------------------------------------------
    # LOGIN CHECK
    # -----------------------------------------------------

    if "user_id" not in session:

        return redirect("/")


    # -----------------------------------------------------
    # DEFAULT VALUES
    # -----------------------------------------------------

    prediction_result = None

    confidence = None

    risk_level = None

    risk_class = None

    reasons = []


    # =====================================================
    # POST REQUEST
    # =====================================================

    if request.method == "POST":

        try:

            # -------------------------------------------------
            # READ FORM VALUES
            # -------------------------------------------------

            amount = float(
                request.form.get(
                    "amount",
                    1000
                )
            )


            location = request.form.get(
                "location",
                "Hyderabad"
            )


            transaction_type = request.form.get(
                "transaction_type",
                "UPI"
            )


            authorization_method = request.form.get(
                "authorization_method",
                "PIN"
            )


            session_duration = float(
                request.form.get(
                    "session_duration",
                    60
                )
            )


            authentication_attempts = int(
                request.form.get(
                    "authentication_attempts",
                    1
                )
            )


            receiver_account_age = float(
                request.form.get(
                    "receiver_account_age",
                    365
                )
            )


            receiver_transaction_history = float(
                request.form.get(
                    "receiver_transaction_history",
                    500
                )
            )


            unusual_device_flag = int(
                request.form.get(
                    "unusual_device_flag",
                    0
                )
            )


            unusual_ip_flag = int(
                request.form.get(
                    "unusual_ip_flag",
                    0
                )
            )


            unusual_location_flag = int(
                request.form.get(
                    "unusual_location_flag",
                    0
                )
            )


            # =================================================
            # CREATE SAMPLE TRANSACTION
            # =================================================

            sample = dataset.iloc[[0]].copy()


            # =================================================
            # UPDATE INPUT VALUES
            # =================================================

            if "amount" in sample.columns:

                sample["amount"] = amount


            if "location" in sample.columns:

                sample["location"] = location


            if "transaction_type" in sample.columns:

                sample["transaction_type"] = transaction_type


            if "authorization_method" in sample.columns:

                sample["authorization_method"] = (
                    authorization_method
                )


            if "session_duration" in sample.columns:

                sample["session_duration"] = (
                    session_duration
                )


            if "authentication_attempts" in sample.columns:

                sample["authentication_attempts"] = (
                    authentication_attempts
                )


            if "receiver_account_age" in sample.columns:

                sample["receiver_account_age"] = (
                    receiver_account_age
                )


            if "receiver_transaction_history" in sample.columns:

                sample["receiver_transaction_history"] = (
                    receiver_transaction_history
                )


            if "unusual_device_flag" in sample.columns:

                sample["unusual_device_flag"] = (
                    unusual_device_flag
                )


            if "unusual_ip_flag" in sample.columns:

                sample["unusual_ip_flag"] = (
                    unusual_ip_flag
                )


            if "unusual_location_flag" in sample.columns:

                sample["unusual_location_flag"] = (
                    unusual_location_flag
                )


            # =================================================
            # FRAUD REASON ANALYSIS
            # =================================================

            fraud_score = 0


            # High transaction amount
            if amount > 100000:

                fraud_score += 2

                reasons.append(
                    "High transaction amount detected."
                )


            elif amount > 50000:

                fraud_score += 1

                reasons.append(
                    "Transaction amount is relatively high."
                )


            # Unusual device
            if unusual_device_flag == 1:

                fraud_score += 2

                reasons.append(
                    "Transaction is being performed from an unusual device."
                )


            # Unusual IP
            if unusual_ip_flag == 1:

                fraud_score += 2

                reasons.append(
                    "Unusual IP address detected."
                )


            # Unusual location
            if unusual_location_flag == 1:

                fraud_score += 2

                reasons.append(
                    "Unusual transaction location detected."
                )


            # Multiple authentication attempts
            if authentication_attempts >= 3:

                fraud_score += 2

                reasons.append(
                    "Multiple authentication attempts detected."
                )


            elif authentication_attempts == 2:

                fraud_score += 1

                reasons.append(
                    "More than one authentication attempt detected."
                )


            # New receiver account
            if receiver_account_age < 30:

                fraud_score += 2

                reasons.append(
                    "Receiver account is very new."
                )


            elif receiver_account_age < 90:

                fraud_score += 1

                reasons.append(
                    "Receiver account has a relatively short history."
                )


            # Low receiver transaction history
            if receiver_transaction_history < 10:

                fraud_score += 2

                reasons.append(
                    "Receiver has very limited transaction history."
                )


            elif receiver_transaction_history < 50:

                fraud_score += 1

                reasons.append(
                    "Receiver has low transaction history."
                )


            # =================================================
            # MACHINE LEARNING PREDICTION
            # =================================================

            ml_result = model.predict(sample)[0]


            try:

                probabilities = model.predict_proba(sample)[0]

                ml_confidence = round(
                    probabilities.max() * 100,
                    2
                )

            except Exception:

                ml_confidence = 90.0


            # =================================================
            # FINAL PREDICTION
            # =================================================

            # Strong fraud indicators
            if fraud_score >= 4:

                prediction_result = "Fraud"

                confidence = min(
                    99.50,
                    90 + (fraud_score * 1.2)
                )


            elif fraud_score >= 2 and ml_result == 1:

                prediction_result = "Fraud"

                confidence = max(
                    ml_confidence,
                    92.0
                )


            elif ml_result == 1:

                prediction_result = "Fraud"

                confidence = ml_confidence


            else:

                prediction_result = "Genuine"

                confidence = ml_confidence


            confidence = round(
                confidence,
                2
            )


            # =================================================
            # RISK LEVEL
            # =================================================

            if prediction_result == "Fraud":

                if confidence >= 90:

                    risk_level = "High"

                    risk_class = "danger"


                elif confidence >= 70:

                    risk_level = "Medium"

                    risk_class = "warning"


                else:

                    risk_level = "Low"

                    risk_class = "info"


            else:

                if confidence >= 90:

                    risk_level = "Low"

                    risk_class = "success"


                elif confidence >= 70:

                    risk_level = "Medium"

                    risk_class = "warning"


                else:

                    risk_level = "Medium"

                    risk_class = "warning"


            # =================================================
            # GENUINE TRANSACTION REASONS
            # =================================================

            if prediction_result == "Genuine":

                reasons = []


                if amount <= 50000:

                    reasons.append(
                        "Transaction amount is within a normal range."
                    )


                if unusual_device_flag == 0:

                    reasons.append(
                        "No unusual device detected."
                    )


                if unusual_ip_flag == 0:

                    reasons.append(
                        "No unusual IP address detected."
                    )


                if unusual_location_flag == 0:

                    reasons.append(
                        "No unusual location detected."
                    )


                if authentication_attempts <= 1:

                    reasons.append(
                        "Authentication attempts are normal."
                    )


                if receiver_account_age >= 90:

                    reasons.append(
                        "Receiver account has sufficient history."
                    )


                if receiver_transaction_history >= 50:

                    reasons.append(
                        "Receiver has sufficient transaction history."
                    )


                # Fallback
                if not reasons:

                    reasons.append(
                        "Transaction does not show strong fraud indicators."
                    )


            # =================================================
            # SAVE PREDICTION HISTORY
            # =================================================

            conn = sqlite3.connect(
                DATABASE
            )

            cursor = conn.cursor()


            cursor.execute(
                """
                INSERT INTO prediction_history
                (
                    user_email,
                    amount,
                    prediction,
                    confidence
                )
                VALUES (?, ?, ?, ?)
                """,
                (
                    session["email"],
                    amount,
                    prediction_result,
                    confidence
                )
            )


            conn.commit()

            conn.close()


        # =====================================================
        # INVALID INPUT
        # =====================================================

        except ValueError:

            flash(
                "Please enter valid transaction values.",
                "danger"
            )

            return render_template(
                "prediction.html",
                prediction=None,
                confidence=None,
                risk_level=None,
                risk_class=None,
                reasons=[]
            )


        # =====================================================
        # OTHER ERROR
        # =====================================================

        except Exception as e:

            print(
                "Prediction Error:",
                e
            )

            flash(
                "Unable to process the transaction. Please check the input values.",
                "danger"
            )

            return render_template(
                "prediction.html",
                prediction=None,
                confidence=None,
                risk_level=None,
                risk_class=None,
                reasons=[]
            )


    # =========================================================
    # RETURN PAGE
    # =========================================================

    return render_template(
        "prediction.html",

        prediction=prediction_result,

        confidence=confidence,

        risk_level=risk_level,

        risk_class=risk_class,

        reasons=reasons
    )