from flask import Blueprint, render_template, session, redirect
import sqlite3
from config import DATABASE

analysis_bp = Blueprint("analysis", __name__)

@analysis_bp.route("/analysis")
def analysis():

    if "user_id" not in session:
        return redirect("/")

    conn = sqlite3.connect(DATABASE)
    cursor = conn.cursor()

    cursor.execute("SELECT COUNT(*) FROM prediction_history")
    total = cursor.fetchone()[0]

    cursor.execute("SELECT COUNT(*) FROM prediction_history WHERE prediction='Fraud'")
    fraud = cursor.fetchone()[0]

    cursor.execute("SELECT COUNT(*) FROM prediction_history WHERE prediction='Genuine'")
    genuine = cursor.fetchone()[0]

    conn.close()

    return render_template(
        "analysis.html",
        total=total,
        fraud=fraud,
        genuine=genuine
    )