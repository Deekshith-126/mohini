from flask import Blueprint, render_template, session, redirect

about_bp = Blueprint("about", __name__)

@about_bp.route("/about")
def about():

    if "user_id" not in session:
        return redirect("/")

    return render_template("about.html")