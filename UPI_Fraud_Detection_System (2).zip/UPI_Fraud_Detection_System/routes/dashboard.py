from flask import Blueprint, render_template, session, redirect
import sqlite3
from config import DATABASE

dashboard_bp = Blueprint("dashboard", __name__)


@dashboard_bp.route("/dashboard")
def dashboard():

    # Check Login
    if "user_id" not in session:
        return redirect("/")

    conn = sqlite3.connect(DATABASE)
    cursor = conn.cursor()

    # ==========================
    # TOTAL USERS
    # ==========================
    cursor.execute("SELECT COUNT(*) FROM users")
    total_users = cursor.fetchone()[0]

    # ==========================
    # TOTAL PREDICTIONS
    # ==========================
    cursor.execute("SELECT COUNT(*) FROM prediction_history")
    total_predictions = cursor.fetchone()[0]

    # ==========================
    # FRAUD
    # ==========================
    cursor.execute("""
        SELECT COUNT(*)
        FROM prediction_history
        WHERE prediction='Fraud'
    """)
    fraud_predictions = cursor.fetchone()[0]

    # ==========================
    # GENUINE
    # ==========================
    cursor.execute("""
        SELECT COUNT(*)
        FROM prediction_history
        WHERE prediction='Genuine'
    """)
    genuine_predictions = cursor.fetchone()[0]

    # ==========================
    # MAX AMOUNT
    # ==========================
    cursor.execute("""
        SELECT MAX(amount)
        FROM prediction_history
    """)
    highest_amount = cursor.fetchone()[0]

    if highest_amount is None:
        highest_amount = 0

    # ==========================
    # AVERAGE AMOUNT
    # ==========================
    cursor.execute("""
        SELECT AVG(amount)
        FROM prediction_history
    """)
    average_amount = cursor.fetchone()[0]

    if average_amount is None:
        average_amount = 0

    # ==========================
    # LAST 5 PREDICTIONS
    # ==========================
    cursor.execute("""
        SELECT amount,prediction,confidence,created_at
        FROM prediction_history
        ORDER BY id DESC
        LIMIT 5
    """)

    recent = cursor.fetchall()

    conn.close()

    # ==========================
    # FRAUD RATE
    # ==========================
    if total_predictions == 0:

        fraud_rate = 0
        genuine_rate = 0

    else:

        fraud_rate = round(
            fraud_predictions * 100 / total_predictions,
            2
        )

        genuine_rate = round(
            genuine_predictions * 100 / total_predictions,
            2
        )

    return render_template(

        "dashboard.html",

        email=session.get("email"),

        total_users=total_users,

        total_predictions=total_predictions,

        fraud_predictions=fraud_predictions,

        genuine_predictions=genuine_predictions,

        fraud_rate=fraud_rate,

        genuine_rate=genuine_rate,

        highest_amount=highest_amount,

        average_amount=round(average_amount,2),

        recent=recent

    )