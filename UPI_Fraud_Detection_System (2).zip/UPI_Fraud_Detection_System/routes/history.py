from flask import Blueprint, render_template, session, redirect, send_file, request
import sqlite3
import pandas as pd
from config import DATABASE

history_bp = Blueprint("history", __name__)


# ============================
# VIEW PREDICTION HISTORY
# ============================

@history_bp.route("/prediction_history")
def prediction_history():

    if "user_id" not in session:
        return redirect("/")

    conn = sqlite3.connect(DATABASE)
    cursor = conn.cursor()

    cursor.execute("""
        SELECT amount,
               prediction,
               confidence,
               created_at
        FROM prediction_history
        WHERE user_email = ?
        ORDER BY id DESC
    """, (session["email"],))

    history = cursor.fetchall()

    conn.close()

    return render_template(
        "prediction_history.html",
        history=history
    )


# ============================
# DELETE ALL MY HISTORY
# ============================

@history_bp.route("/delete_history", methods=["POST"])
def delete_history():

    if "user_id" not in session:
        return redirect("/")

    conn = sqlite3.connect(DATABASE)
    cursor = conn.cursor()

    cursor.execute("""
        DELETE FROM prediction_history
        WHERE user_email = ?
    """, (session["email"],))

    conn.commit()
    conn.close()

    return redirect("/prediction_history")


# ============================
# DOWNLOAD HISTORY
# ============================

@history_bp.route("/download_history")
def download_history():

    if "user_id" not in session:
        return redirect("/")

    conn = sqlite3.connect(DATABASE)

    df = pd.read_sql_query("""
        SELECT amount,
               prediction,
               confidence,
               created_at
        FROM prediction_history
        WHERE user_email = ?
        ORDER BY id DESC
    """, conn, params=(session["email"],))

    conn.close()

    filename = "prediction_history.csv"

    df.to_csv(filename, index=False)

    return send_file(
        filename,
        as_attachment=True
    )