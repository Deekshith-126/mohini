from flask import Blueprint, render_template, request, redirect, flash, session
import sqlite3
import bcrypt
from datetime import datetime
from config import DATABASE


# =========================================================
# CREATE BLUEPRINT
# =========================================================

auth_bp = Blueprint("auth", __name__)


# =========================================================
# DATABASE HELPER
# =========================================================

def create_user_sessions_table():

    conn = sqlite3.connect(DATABASE)
    cursor = conn.cursor()

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS user_sessions (
            user_id INTEGER PRIMARY KEY,
            login_time TEXT,
            last_activity TEXT,
            is_online INTEGER DEFAULT 0
        )
    """)

    conn.commit()
    conn.close()


# Create table when this file starts
create_user_sessions_table()


# =========================================================
# LOGIN
# =========================================================

@auth_bp.route("/", methods=["GET", "POST"])
def login():

    if request.method == "POST":

        email = request.form.get("email", "").strip()
        password = request.form.get("password", "")

        if not email or not password:

            flash(
                "Please enter email and password.",
                "danger"
            )

            return render_template("login.html")

        conn = sqlite3.connect(DATABASE)
        cursor = conn.cursor()

        cursor.execute(
            """
            SELECT id, name, email, password
            FROM users
            WHERE email=?
            """,
            (email,)
        )

        user = cursor.fetchone()

        conn.close()

        if user:

            try:

                if bcrypt.checkpw(
                    password.encode("utf-8"),
                    user[3].encode("utf-8")
                ):

                    # =====================================
                    # CREATE LOGIN SESSION
                    # =====================================

                    session["user_id"] = user[0]
                    session["user_name"] = user[1]
                    session["email"] = user[2]

                    # =====================================
                    # UPDATE USER LOGIN STATUS
                    # =====================================

                    now = datetime.now().strftime(
                        "%Y-%m-%d %H:%M:%S"
                    )

                    conn = sqlite3.connect(DATABASE)
                    cursor = conn.cursor()

                    cursor.execute(
                        """
                        INSERT OR REPLACE INTO user_sessions
                        (
                            user_id,
                            login_time,
                            last_activity,
                            is_online
                        )
                        VALUES (?, ?, ?, ?)
                        """,
                        (
                            user[0],
                            now,
                            now,
                            1
                        )
                    )

                    conn.commit()
                    conn.close()

                    flash(
                        "Login Successful!",
                        "success"
                    )

                    return redirect("/dashboard")

            except Exception:

                pass

        flash(
            "Invalid Email or Password.",
            "danger"
        )

    return render_template("login.html")


# =========================================================
# REGISTER
# =========================================================

@auth_bp.route("/register", methods=["GET", "POST"])
def register():

    if request.method == "POST":

        name = request.form.get(
            "name",
            ""
        ).strip()

        email = request.form.get(
            "email",
            ""
        ).strip()

        password = request.form.get(
            "password",
            ""
        )

        confirm_password = request.form.get(
            "confirm_password",
            ""
        )

        # =====================================
        # EMPTY FIELD VALIDATION
        # =====================================

        if not name or not email or not password or not confirm_password:

            flash(
                "Please fill all fields.",
                "danger"
            )

            return render_template(
                "register.html"
            )

        # =====================================
        # PASSWORD MATCH
        # =====================================

        if password != confirm_password:

            flash(
                "Passwords do not match.",
                "danger"
            )

            return render_template(
                "register.html"
            )

        # =====================================
        # PASSWORD LENGTH
        # =====================================

        if len(password) < 6:

            flash(
                "Password must contain at least 6 characters.",
                "danger"
            )

            return render_template(
                "register.html"
            )

        # =====================================
        # HASH PASSWORD
        # =====================================

        hashed_password = bcrypt.hashpw(
            password.encode("utf-8"),
            bcrypt.gensalt()
        ).decode("utf-8")

        conn = sqlite3.connect(DATABASE)
        cursor = conn.cursor()

        try:

            cursor.execute(
                """
                INSERT INTO users
                (
                    name,
                    email,
                    password
                )
                VALUES (?, ?, ?)
                """,
                (
                    name,
                    email,
                    hashed_password
                )
            )

            conn.commit()

            flash(
                "Registration Successful! Please Login.",
                "success"
            )

            return redirect("/")

        except sqlite3.IntegrityError:

            flash(
                "Email already exists. Please use another email.",
                "danger"
            )

        finally:

            conn.close()

    return render_template(
        "register.html"
    )


# =========================================================
# FORGOT PASSWORD
# =========================================================

@auth_bp.route(
    "/forgot_password",
    methods=["GET", "POST"]
)
def forgot_password():

    if request.method == "POST":

        email = request.form.get(
            "email",
            ""
        ).strip()

        if not email:

            flash(
                "Please enter your registered email.",
                "danger"
            )

            return render_template(
                "forgot_password.html"
            )

        conn = sqlite3.connect(DATABASE)
        cursor = conn.cursor()

        cursor.execute(
            """
            SELECT id, name, email
            FROM users
            WHERE email=?
            """,
            (email,)
        )

        user = cursor.fetchone()

        conn.close()

        if user:

            # Store email temporarily
            session["reset_email"] = user[2]

            return redirect(
                "/reset_password"
            )

        flash(
            "Email address not found. Please check your registered email.",
            "danger"
        )

    return render_template(
        "forgot_password.html"
    )


# =========================================================
# RESET PASSWORD
# =========================================================

@auth_bp.route(
    "/reset_password",
    methods=["GET", "POST"]
)
def reset_password():

    # =====================================
    # CHECK RESET SESSION
    # =====================================

    if "reset_email" not in session:

        flash(
            "Please enter your registered email first.",
            "warning"
        )

        return redirect(
            "/forgot_password"
        )

    if request.method == "POST":

        password = request.form.get(
            "password",
            ""
        )

        confirm_password = request.form.get(
            "confirm_password",
            ""
        )

        # =====================================
        # EMPTY PASSWORD
        # =====================================

        if not password or not confirm_password:

            flash(
                "Please enter both password fields.",
                "danger"
            )

            return render_template(
                "reset_password.html"
            )

        # =====================================
        # PASSWORD MATCH
        # =====================================

        if password != confirm_password:

            flash(
                "Passwords do not match.",
                "danger"
            )

            return render_template(
                "reset_password.html"
            )

        # =====================================
        # PASSWORD LENGTH
        # =====================================

        if len(password) < 6:

            flash(
                "Password must contain at least 6 characters.",
                "danger"
            )

            return render_template(
                "reset_password.html"
            )

        # =====================================
        # HASH NEW PASSWORD
        # =====================================

        hashed_password = bcrypt.hashpw(
            password.encode("utf-8"),
            bcrypt.gensalt()
        ).decode("utf-8")

        conn = sqlite3.connect(DATABASE)
        cursor = conn.cursor()

        cursor.execute(
            """
            UPDATE users
            SET password=?
            WHERE email=?
            """,
            (
                hashed_password,
                session["reset_email"]
            )
        )

        conn.commit()
        conn.close()

        # Remove reset session
        session.pop(
            "reset_email",
            None
        )

        flash(
            "Password reset successfully! Please login with your new password.",
            "success"
        )

        return redirect("/")

    return render_template(
        "reset_password.html"
    )


# =========================================================
# USER DETAILS / USER MANAGEMENT
# =========================================================

@auth_bp.route("/users")
def users():

    # =====================================
    # LOGIN CHECK
    # =====================================

    if "user_id" not in session:

        return redirect("/")

    conn = sqlite3.connect(DATABASE)
    cursor = conn.cursor()

    # =====================================
    # GET USER DETAILS
    # =====================================

    cursor.execute(
        """
        SELECT
            users.id,
            users.name,
            users.email,
            user_sessions.login_time,
            user_sessions.last_activity,
            user_sessions.is_online
        FROM users
        LEFT JOIN user_sessions
        ON users.id = user_sessions.user_id
        ORDER BY users.id DESC
        """
    )

    user_list = cursor.fetchall()

    # =====================================
    # TOTAL USERS
    # =====================================

    cursor.execute(
        """
        SELECT COUNT(*)
        FROM users
        """
    )

    total_users = cursor.fetchone()[0]

    # =====================================
    # ONLINE USERS
    # =====================================

    cursor.execute(
        """
        SELECT COUNT(*)
        FROM user_sessions
        WHERE is_online=1
        """
    )

    online_users = cursor.fetchone()[0]

    # =====================================
    # OFFLINE USERS
    # =====================================

    offline_users = total_users - online_users

    conn.close()

    return render_template(
        "users.html",
        users=user_list,
        total_users=total_users,
        online_users=online_users,
        offline_users=offline_users
    )


# =========================================================
# LOGOUT
# =========================================================

@auth_bp.route("/logout")
def logout():

    # =====================================
    # MARK USER OFFLINE
    # =====================================

    if "user_id" in session:

        try:

            conn = sqlite3.connect(DATABASE)
            cursor = conn.cursor()

            cursor.execute(
                """
                UPDATE user_sessions
                SET is_online=0
                WHERE user_id=?
                """,
                (session["user_id"],)
            )

            conn.commit()
            conn.close()

        except Exception:

            pass

    # =====================================
    # CLEAR LOGIN SESSION
    # =====================================

    session.clear()

    flash(
        "You have been logged out successfully.",
        "success"
    )

    return redirect("/")