from flask import Blueprint, render_template, session, redirect
import sqlite3
from config import DATABASE

reports_bp = Blueprint("reports", __name__)


@reports_bp.route("/reports")
def reports():

    # -----------------------------------------
    # LOGIN CHECK
    # -----------------------------------------
    if "user_id" not in session:
        return redirect("/")


    conn = sqlite3.connect(DATABASE)
    cursor = conn.cursor()


    # -----------------------------------------
    # TOTAL PREDICTIONS
    # -----------------------------------------
    cursor.execute("""
        SELECT COUNT(*)
        FROM prediction_history
    """)

    total = cursor.fetchone()[0]


    # -----------------------------------------
    # FRAUD PREDICTIONS
    # -----------------------------------------
    cursor.execute("""
        SELECT COUNT(*)
        FROM prediction_history
        WHERE prediction = 'Fraud'
    """)

    fraud = cursor.fetchone()[0]


    # -----------------------------------------
    # GENUINE PREDICTIONS
    # -----------------------------------------
    cursor.execute("""
        SELECT COUNT(*)
        FROM prediction_history
        WHERE prediction = 'Genuine'
    """)

    genuine = cursor.fetchone()[0]


    # -----------------------------------------
    # TOTAL TRANSACTION AMOUNT
    # -----------------------------------------
    cursor.execute("""
        SELECT COALESCE(SUM(amount), 0)
        FROM prediction_history
    """)

    total_amount = cursor.fetchone()[0]


    # -----------------------------------------
    # AVERAGE TRANSACTION AMOUNT
    # -----------------------------------------
    cursor.execute("""
        SELECT COALESCE(AVG(amount), 0)
        FROM prediction_history
    """)

    average_amount = cursor.fetchone()[0]


    # -----------------------------------------
    # HIGHEST TRANSACTION AMOUNT
    # -----------------------------------------
    cursor.execute("""
        SELECT COALESCE(MAX(amount), 0)
        FROM prediction_history
    """)

    highest_amount = cursor.fetchone()[0]


    # -----------------------------------------
    # AVERAGE CONFIDENCE
    # -----------------------------------------
    cursor.execute("""
        SELECT COALESCE(AVG(confidence), 0)
        FROM prediction_history
    """)

    average_confidence = cursor.fetchone()[0]


    # -----------------------------------------
    # RECENT PREDICTIONS
    # -----------------------------------------
    cursor.execute("""
        SELECT
            amount,
            prediction,
            confidence,
            created_at
        FROM prediction_history
        ORDER BY id DESC
        LIMIT 10
    """)

    recent = cursor.fetchall()


    # -----------------------------------------
    # FRAUD AND GENUINE PERCENTAGE
    # -----------------------------------------
    if total > 0:

        fraud_percent = round(
            (fraud / total) * 100,
            2
        )

        genuine_percent = round(
            (genuine / total) * 100,
            2
        )

    else:

        fraud_percent = 0
        genuine_percent = 0


    # -----------------------------------------
    # ROUND VALUES
    # -----------------------------------------
    total_amount = round(total_amount, 2)
    average_amount = round(average_amount, 2)
    highest_amount = round(highest_amount, 2)
    average_confidence = round(average_confidence, 2)


    conn.close()


    # -----------------------------------------
    # SEND DATA TO HTML
    # -----------------------------------------
    return render_template(
        "reports.html",

        total=total,

        fraud=fraud,

        genuine=genuine,

        fraud_percent=fraud_percent,

        genuine_percent=genuine_percent,

        total_amount=total_amount,

        average_amount=average_amount,

        highest_amount=highest_amount,

        average_confidence=average_confidence,

        recent=recent
    )