from flask import Blueprint, render_template, session, redirect
import pandas as pd

dataset_bp = Blueprint("dataset_bp", __name__)

@dataset_bp.route("/dataset")
def dataset():

    if "user_id" not in session:
        return redirect("/")

    df = pd.read_csv("dataset/upi_fraud_detection.csv")

    data = df.head(100).to_dict(orient="records")
    columns = df.columns.tolist()

    return render_template(
        "dataset.html",
        data=data,
        columns=columns
    )