from flask import Blueprint, render_template, session, redirect
import pandas as pd

model_bp = Blueprint("model_bp", __name__)

@model_bp.route("/model_performance")
def model_performance():

    if "user_id" not in session:
        return redirect("/")

    try:
        df = pd.read_csv("models/model_comparison.csv")
        models = df.to_dict(orient="records")
    except:
        models = []

    return render_template(
        "model_performance.html",
        models=models
    )