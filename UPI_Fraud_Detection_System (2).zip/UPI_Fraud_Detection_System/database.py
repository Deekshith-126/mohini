import sqlite3
import os

from config import DATABASE


# =========================================================
# INITIALIZE DATABASE
# =========================================================

def init_database():

    # Create database folder if it does not exist
    database_folder = os.path.dirname(DATABASE)

    if database_folder:
        os.makedirs(database_folder, exist_ok=True)

    # Connect to SQLite database
    conn = sqlite3.connect(DATABASE)

    cursor = conn.cursor()


    # =====================================================
    # USERS TABLE
    # =====================================================

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            email TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)


    # =====================================================
    # LOGIN HISTORY TABLE
    # =====================================================

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS login_history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_email TEXT NOT NULL,
            login_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            logout_time TIMESTAMP
        )
    """)


    # =====================================================
    # PREDICTION HISTORY TABLE
    # =====================================================

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS prediction_history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_email TEXT NOT NULL,
            amount REAL,
            prediction TEXT,
            confidence REAL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)


    # Save changes
    conn.commit()

    # Close database
    conn.close()

    print("Database initialized successfully.")


# =========================================================
# RUN DIRECTLY
# =========================================================

if __name__ == "__main__":
    init_database()