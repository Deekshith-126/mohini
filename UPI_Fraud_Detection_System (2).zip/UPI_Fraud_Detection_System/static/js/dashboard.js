// ===============================
// UPI Fraud Detection Dashboard
// ===============================

document.addEventListener("DOMContentLoaded", function () {

    // Counter Animation
    const counters = document.querySelectorAll(".counter");

    counters.forEach(counter => {

        const updateCounter = () => {

            const target = Number(counter.getAttribute("data-target"));
            const count = Number(counter.innerText);

            const increment = Math.ceil(target / 50);

            if (count < target) {

                counter.innerText = count + increment;

                setTimeout(updateCounter, 30);

            } else {

                counter.innerText = target;

            }

        };

        updateCounter();

    });

    // Line Chart
    const line = document.getElementById("lineChart");

    if (line) {

        new Chart(line, {

            type: "line",

            data: {

                labels: ["Jan","Feb","Mar","Apr","May","Jun"],

                datasets: [{

                    label: "Fraud Cases",

                    data: [4,7,6,9,5,10],

                    borderColor: "#0d6efd",

                    backgroundColor: "rgba(13,110,253,0.15)",

                    fill: true,

                    tension: .4

                }]

            },

            options: {

                responsive: true

            }

        });

    }

    // Pie Chart
    const pie = document.getElementById("pieChart");

    if (pie) {

        new Chart(pie, {

            type: "pie",

            data: {

                labels: ["Fraud","Genuine"],

                datasets: [{

                    data: [30,70],

                    backgroundColor: [

                        "#dc3545",

                        "#198754"

                    ]

                }]

            }

        });

    }

    // Doughnut Chart
    const doughnut = document.getElementById("doughnutChart");

    if (doughnut) {

        new Chart(doughnut, {

            type: "doughnut",

            data: {

                labels: [

                    "Fraud",

                    "Safe"

                ],

                datasets: [{

                    data: [

                        30,

                        70

                    ],

                    backgroundColor: [

                        "#dc3545",

                        "#0d6efd"

                    ]

                }]

            }

        });

    }

    // Bar Chart
    const bar = document.getElementById("barChart");

    if (bar) {

        new Chart(bar, {

            type: "bar",

            data: {

                labels: [

                    "Transfer",

                    "Merchant",

                    "Bill",

                    "Recharge"

                ],

                datasets: [{

                    label: "Transactions",

                    data: [

                        250,

                        190,

                        110,

                        90

                    ],

                    backgroundColor: [

                        "#0d6efd",

                        "#20c997",

                        "#ffc107",

                        "#dc3545"

                    ]

                }]

            },

            options: {

                responsive: true

            }

        });

    }

});