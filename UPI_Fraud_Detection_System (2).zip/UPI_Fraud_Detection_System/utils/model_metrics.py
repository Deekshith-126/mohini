from sklearn.metrics import *

def evaluate(y_test,pred,prob):

    return {

        "Accuracy":
        accuracy_score(y_test,pred),

        "Precision":
        precision_score(y_test,pred),

        "Recall":
        recall_score(y_test,pred),

        "F1":
        f1_score(y_test,pred),

        "ROC":
        roc_auc_score(y_test,prob)

    }