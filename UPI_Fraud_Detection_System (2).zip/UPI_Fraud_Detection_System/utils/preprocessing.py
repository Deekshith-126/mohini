import pandas as pd
import numpy as np


DROP_COLUMNS = [
    "transaction_id",
    "user_id",
    "merchant_id",
    "timestamp"
]


TARGET_COLUMN = "is_fraud"


def clean_dataset(df):

    df = df.copy()

    # Remove unwanted columns
    for col in DROP_COLUMNS:

        if col in df.columns:

            df.drop(columns=col, inplace=True)

    return df


def split_features(df):

    y = df[TARGET_COLUMN]

    X = df.drop(TARGET_COLUMN, axis=1)

    return X, y


def get_column_types(df):

    categorical = df.select_dtypes(include="object").columns.tolist()

    numerical = df.select_dtypes(exclude="object").columns.tolist()

    return categorical, numerical