import os
import joblib
import warnings
import pandas as pd
import numpy as np

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import OrdinalEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer

from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    roc_auc_score
)

# Models
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import (
    RandomForestClassifier,
    GradientBoostingClassifier,
    AdaBoostClassifier,
    ExtraTreesClassifier
)
from sklearn.neighbors import KNeighborsClassifier
from sklearn.svm import SVC
from sklearn.naive_bayes import GaussianNB

from xgboost import XGBClassifier
from lightgbm import LGBMClassifier
from catboost import CatBoostClassifier

warnings.filterwarnings("ignore")

DATASET = "dataset/upi_fraud_detection.csv"

df = pd.read_csv(DATASET)

print("Dataset Shape :", df.shape)

# Remove ID columns

drop_columns = [
    "transaction_id",
    "user_id",
    "merchant_id",
    "timestamp"
]

for col in drop_columns:
    if col in df.columns:
        df.drop(col, axis=1, inplace=True)

# Target

y = df["is_fraud"]

X = df.drop("is_fraud", axis=1)

categorical = X.select_dtypes(include="object").columns.tolist()

numeric = X.select_dtypes(exclude="object").columns.tolist()

preprocessor = ColumnTransformer(

    transformers=[

        (
            "cat",

            Pipeline(

                steps=[

                    ("imputer",
                     SimpleImputer(strategy="most_frequent")),

                    ("encoder",
                     OrdinalEncoder(
                         handle_unknown="use_encoded_value",
                         unknown_value=-1
                     ))

                ]

            ),

            categorical

        ),

        (

            "num",

            Pipeline(

                steps=[

                    ("imputer",
                     SimpleImputer(strategy="median"))

                ]

            ),

            numeric

        )

    ]

)

X_train, X_test, y_train, y_test = train_test_split(

    X,
    y,
    test_size=0.2,
    random_state=42,
    stratify=y

)

models = {

    "Logistic Regression": LogisticRegression(max_iter=1000),

    "Decision Tree": DecisionTreeClassifier(),

    "Random Forest": RandomForestClassifier(),

    "Gradient Boosting": GradientBoostingClassifier(),

    "AdaBoost": AdaBoostClassifier(),

    "Extra Trees": ExtraTreesClassifier(),

    "KNN": KNeighborsClassifier(),

    "SVM": SVC(probability=True),

    "Naive Bayes": GaussianNB(),

    "XGBoost": XGBClassifier(eval_metric="logloss"),

    "LightGBM": LGBMClassifier(),

    "CatBoost": CatBoostClassifier(verbose=0)

}

os.makedirs("models", exist_ok=True)

results = []

best_accuracy = 0

best_pipeline = None

best_model_name = ""

for name, model in models.items():

    print(f"Training {name}...")

    pipeline = Pipeline([

        ("preprocessor", preprocessor),

        ("model", model)

    ])

    pipeline.fit(X_train, y_train)

    pred = pipeline.predict(X_test)

    prob = pipeline.predict_proba(X_test)[:, 1]

    accuracy = accuracy_score(y_test, pred)

    precision = precision_score(y_test, pred)

    recall = recall_score(y_test, pred)

    f1 = f1_score(y_test, pred)

    roc = roc_auc_score(y_test, prob)

    results.append([

        name,

        accuracy,

        precision,

        recall,

        f1,

        roc

    ])

    joblib.dump(
        pipeline,
        f"models/{name.replace(' ','_')}.pkl"
    )

    if accuracy > best_accuracy:

        best_accuracy = accuracy

        best_pipeline = pipeline

        best_model_name = name

joblib.dump(best_pipeline,
            "models/best_model.pkl")

results = pd.DataFrame(

    results,

    columns=[

        "Model",

        "Accuracy",

        "Precision",

        "Recall",

        "F1",

        "ROC_AUC"

    ]

)

results = results.sort_values(
    by="Accuracy",
    ascending=False
)

print("\n")
print(results)

print("\nBest Model :", best_model_name)
print("Accuracy :", best_accuracy)

results.to_csv(
    "models/model_comparison.csv",
    index=False
)

print("\nTraining Completed Successfully!")