import os

BASE_DIR = os.path.abspath(os.path.dirname(__file__))

DATABASE = os.path.join(BASE_DIR, "database", "fraud_detection.db")

SECRET_KEY = "UPI_FRAUD_DETECTION_SECRET_KEY_2026"

MODEL_FOLDER = os.path.join(BASE_DIR, "models")

BEST_MODEL = os.path.join(MODEL_FOLDER, "best_model.pkl")