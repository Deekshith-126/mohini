from flask import Flask
from config import SECRET_KEY

# Database initialization
from database import init_database


# =========================================================
# IMPORT BLUEPRINTS
# =========================================================

from routes.auth import auth_bp
from routes.dashboard import dashboard_bp
from routes.prediction import prediction_bp
from routes.analysis import analysis_bp
from routes.history import history_bp
from routes.dataset import dataset_bp
from routes.reports import reports_bp
from routes.settings import settings_bp
from routes.about import about_bp
from routes.model_performance import model_bp


# =========================================================
# CREATE FLASK APP
# =========================================================

app = Flask(__name__)


# =========================================================
# SECRET KEY FOR SESSIONS
# =========================================================

app.config["SECRET_KEY"] = SECRET_KEY


# =========================================================
# REGISTER BLUEPRINTS
# =========================================================

app.register_blueprint(auth_bp)
app.register_blueprint(dashboard_bp)
app.register_blueprint(prediction_bp)
app.register_blueprint(analysis_bp)
app.register_blueprint(history_bp)
app.register_blueprint(dataset_bp)
app.register_blueprint(reports_bp)
app.register_blueprint(settings_bp)
app.register_blueprint(about_bp)
app.register_blueprint(model_bp)


# =========================================================
# INITIALIZE DATABASE
# =========================================================

init_database()


# =========================================================
# HOME ROUTE
# =========================================================

@app.route("/home")
def home():

    return "UPI Fraud Detection System is Running Successfully!"


# =========================================================
# RUN FLASK APPLICATION
# =========================================================

if __name__ == "__main__":

    app.run(
        host="127.0.0.1",
        port=5000,
        debug=True
    )